local OBJ = RDV.CLAIMBOARDS.Config()

--[[---------------------------------]]--
--  Prefix
--[[---------------------------------]]--

OBJ:SetPrefix({
    Appension = "Claim Board",
    Color = Color(255,0,0)
})

--[[---------------------------------]]--
--  Reset Settings
--[[---------------------------------]]--

OBJ:SetArrest(true) -- Should the Claimboards be reset if the claimer is arrested?

OBJ:SetDeath(true) -- Should the Claimboards be reset if the claimer is killed?

--[[---------------------------------]]--
--  Header Settings
--[[---------------------------------]]--

OBJ:SetCustomHeaders(false)

OBJ:SetDefaultHeaders({
    "FFA",
    "OOC",
    "Tryouts",
})

--[[---------------------------------]]--
--  Battalions
--[[---------------------------------]]--

OBJ:AddBattalion("212th", {
    "Citizens"
}, Color(224,180,34))

OBJ:AddBattalion("501st", {
    "Gun Dealer",
}, Color(35,35,182))

--[[---------------------------------]]--
--  Admins
--[[---------------------------------]]--

OBJ:SetAdmins({
    "superadmin",
})

--[[---------------------------------]]--
--  Commands
--[[---------------------------------]]--

OBJ:SetCommands({
    Unclaim = "!unclaim", -- Unclaims the sign the Admin is looking at.
    UnclaimAll = "!unclaim_all", -- Unclaims all signs of a selected player.
})